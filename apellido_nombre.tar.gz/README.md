# Integrantes

| DNI       | Nombre | Apellidos        | Grupo |
| :-------- | :----- | :--------------- | ----: |
| 05735354M | Samuel | Espejo Gil       |    BC |
| 06297500P | Noelia | Díaz-Alejo Alejo |    BC |

