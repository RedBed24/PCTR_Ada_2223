# Integrantes

| DNI       | Nombre | Apellidos        | Grupo |
| :-------- | :----- | :--------------- | ----: |
| 05735354M | Samuel | Espejo Gil       |     B |
| 06297500P | Noelia | Díaz-Alejo Alejo |     B |

